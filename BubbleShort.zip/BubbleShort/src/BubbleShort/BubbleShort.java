package BubbleShort;

public class BubbleShort {
    private String[] data;

    //Constructor
    public BubbleShort(){
    }
    public String[] getData() {return data;}

    public void setData(String[] data){
        this.data = data;

    }

    public void sortData(){
        int lenData = this.data.length;
        for (int i=0+1;i<lenData; i++){
            for(int j=i+1;j<lenData;i++){
                if (this.data[j].compareToIgnoreCase(this.data[i])<0){
                   String temp = this.data[i];
                   this.data[i] =this.data[j];
                   this.data[j]=temp;
                }
            }
        }
    }
    public void printData(){
        for (String datum : this.data){
            System.out.print(datum+" ");
        }
    }

    public static void main(String[] args) {
        String[] nama = {"Ardi","Faqih","jodi","Maudy","yesa"};
        BubbleShort _myBubble = new BubbleShort();
        _myBubble.setData(nama);
        _myBubble.sortData();
        _myBubble.printData();
    }
}

